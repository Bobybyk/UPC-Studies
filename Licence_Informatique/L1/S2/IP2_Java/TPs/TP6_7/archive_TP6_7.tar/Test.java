public class Test {
	
	public static void main (String[] args) {

		Automate a = new Automate();

		a.initialistation();	
		a.nEtapes(7);
	}
}