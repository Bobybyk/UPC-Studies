import sys
from tkinter import *
from random import randrange

p=c=d=j1=j2=r1=r2=n1=n2=n3=n4=n5=n6=m1=m2=m3=m4=m5=m6=a1=b1=c1=d1=e1=a2=b2=c2=d2=e2=pr1=pr2=z=0
ran = 5

def random() :
    
    ran = randrange(2)
    if ran == 0 :
        print("Joueur 1 commence !")
        joueur1()
    elif ran == 1 :
        print("Joueur 2 commence !")
        joueur2()
    

def compteur() :

    global p
    global c
    global d
    global r1
    global r2
    global pr1
    global pr2
    
    if c == 1 and d == 0 :
        print("au tour de joueur 2 !")
        joueur2()
    if d == 1 and c == 0 :
        print("au tour de joueur 1 !")
        joueur1()
    if r1 != 0 and r2 != 0 :
        p = p + 1
        print("Fin de manche n° ",p)
        if r1 < r2 :
            print ("Joueur 2 remporte la manche")
            pr2 = pr2 + 1
        elif r2 < r1 :
            print ("Joueur 1 remporte la manche")
            pr1 = pr1 + 1
        elif r2 == r1 :
            print ("égalité")
            pr1 = pr1 + 1
            pr2 = pr2 + 1
        if r2 != r1 and 2 < p :
            if r2 < r1 :
                print("Joueur 1 remporte la partie !")
                print("GG Joueur 1 !")
                s = float (input("entrer 0 pour quitter"))
                if s == 0 :
                    System.exit
            if r1 < r2 :
                print("Joueur 2 remporte la partie !")
                print("GG Joueur 2 !")
                s = float (input("entrer 0 pour quitter"))
                if s == 0 :
                    System.exit
        else :
            c = 0
            d = 0            
            main()        


def main() :


    t = float (input("Joueur 1 commence, entrer : 1 ; Joueur 2 commence, entrer 2 ; Tour aléatoire, entrer : 3 -> "))
    print("--------------------------------")

    if t == 1 :
        print("Joueur 1 commence !")
        joueur1()
    if t == 2 :
        print("Joueur 2 commence !")
        joueur2()
    if t == 3 :
        ran = randrange(2)
    if ran == 0 :
        print("Joueur 1 commence !")
        joueur1()
    elif ran == 1 :
        print("Joueur 2 commence !")
        joueur2()
        
        
    
def joueur1() :

    global c
    global d
    global a1
    global b1
    global c1
    global d1
    global e1
    print("----------------------------")

    

    a1 = randrange(1,7)
    b1 = randrange(1,7)
    c1 = randrange(1,7)
    d1 = randrange(1,7)
    e1 = randrange(1,7)

    print("dé1 = " ,a1)
    print("dé2 = " ,b1)
    print("dé3 = " ,c1)
    print("dé4 = " ,d1)
    print("dé5 = " ,e1)
    print("----------------------------")
    
    q1 = float (input("Relancer dé1 ? 1 ou 0 "))
    q2 = float (input("Relancer dé2 ? 1 ou 0 "))
    q3 = float (input("Relancer dé3 ? 1 ou 0 "))
    q4 = float (input("Relancer dé4 ? 1 ou 0 "))
    q5 = float (input("Relancer dé5 ? 1 ou 0 "))

    if q1 == 1 :
        a1 = randrange(1,7)
    if q2 == 1 :
        b1 = randrange(1,7)    
    if q3 == 1 :
        c1 = randrange(1,7)
    if q4 == 1 :
        d1 = randrange(1,7)
    if q5 == 1 :
        e1 = randrange(1,7)
    print("dé1 = " ,a1)
    print("dé2 = " ,b1)
    print("dé3 = " ,c1)
    print("dé4 = " ,d1)
    print("dé5 = " ,e1)
    c = c + 1
    j1Resultat()
    print("----------------------------")
    

def joueur2() : 

    global c
    global d
    global a2
    global b2
    global c2
    global d2
    global e2
    print("----------------------------")


    a2 = randrange(1,7)
    b2 = randrange(1,7)
    c2 = randrange(1,7)
    d2 = randrange(1,7)
    e2 = randrange(1,7)

    print("dé1 = " ,a2)
    print("dé2 = " ,b2)
    print("dé3 = " ,c2)
    print("dé4 = " ,d2)
    print("dé5 = " ,e2)
    print("----------------------------")
    
    q11 = float (input("Relancer dé1 ? 1 ou 0 "))
    q12 = float (input("Relancer dé2 ? 1 ou 0 "))
    q13 = float (input("Relancer dé3 ? 1 ou 0 "))
    q14 = float (input("Relancer dé4 ? 1 ou 0 "))
    q15 = float (input("Relancer dé5 ? 1 ou 0 "))
    print("----------------------------")
    if q11 == 1 :
        a2 = randrange(1,7)
    if q12 == 1 :
        b2 = randrange(1,7)    
    if q13 == 1 :
        c2 = randrange(1,7)
    if q14 == 1 :
        d2 = randrange(1,7)
    if q15 == 1 :
        e2 = randrange(1,7)
    print("dé1 = " ,a2)
    print("dé2 = " ,b2)
    print("dé3 = " ,c2)
    print("dé4 = " ,d2)
    print("dé5 = " ,e2)
    d = d + 1
    j2Resultat()
    print("----------------------------")

def resultat() :

    global r1
    global n1
    global n2
    global n3
    global n4
    global n5
    global n6
    global j1
    global j2

    print("Score joueur 1 =" , r1)
    print("------------------------")
    print("Score joueur 2 =" , r2)
    print("------------------------")
    compteur()    

def j1Resultat() :

    global r1
    global n1
    global n2
    global n3
    global n4
    global n5
    global n6
    global j1

    j1 = [a1 , b1 , c1 , d1 , e1]

    n1 = j1.count(1)
    n2 = j1.count(2)
    n3 = j1.count(3)
    n4 = j1.count(4)
    n5 = j1.count(5)
    n6 = j1.count(6)

    if m1 == 1 :
        r1 = r1 + 1

    if m2 == 1 :
        r1 = r1 + 1

    if m3 == 1 :
        r1 = r1 + 1

    if m4 == 1 :
        r1 = r1 + 1

    if m5 == 1 :
        r1 = r1 + 1

    if m6 == 1 :
        r1 = r1 + 1
    
    if n1 == 1 and n2 == 1 and n3 == 1 and n4 == 1 and n5 == 1 : #Petite suite
        r1 = r1 + 160

    if n2 == 1 and n3 == 1 and  n4 == 1 and n5 == 1 and n6 == 1 : #Grande suite
        r1 = r1 + 170

    if n1 == 2 :
        r1 = r1 + 20*1
    if n2 == 2 :
        r1 = r1 + 20*2
    if n3 == 2 :
        r1 = r1 + 20*3
    if n4 == 2 :
        r1 = r1 + 20*4
    if n5 == 2 :
        r1 = r1 + 20*5
    if n6 == 2 :
        r1 = r1 + 20*6 #SPaire/DPaire

    if n1 == 3 or n2 == 3 or n3 == 3 or n4 == 3 or n5 == 3 or n6 == 3 :
        r1 = r1 + 150 #Brelan

    if n1 == 4 or n2 == 4 or n3 == 4 or n4 == 4 or n5 == 4 or n6 == 4 :
        r1 = r1 + 180 #Carré

    if n1 == 5 or n2 == 5 or n3 == 5 or n4 == 5 or n5 == 5 or n6 == 5 :
        r1 = r1 + 200
        
    resultat()


def j2Resultat() :

    global r2
    global m1
    global m2
    global m3
    global m4
    global m5
    global m6
    global j2

    j2 = [a2 , b2 , c2 , d2 , e2]

    m1 = j2.count(1)
    m2 = j2.count(2)
    m3 = j2.count(3)
    m4 = j2.count(4)
    m5 = j2.count(5)
    m6 = j2.count(6)
    
    if m1 == 1 :
        r2 = r2 + 1

    if m2 == 1 :
        r2 = r2 + 1

    if m3 == 1 :
        r2 = r2 + 1

    if m4 == 1 :
        r2 = r2 + 1

    if m5 == 1 :
        r2 = r2 + 1

    if m6 == 1 :
        r2 = r2 + 1
                         
    
    if m1 == 1 and m2 == 1 and m3 == 1 and m4 == 1 and m5 == 1 : #Petite suite
        r2 = r2 + 160

    if m2 == 1 and m3 == 1 and  m4 == 1 and m5 == 1 and m6 == 1 : #Grande suite
        r2 = r2 + 170

    if m1 == 2 :
        r2 = r2 + 20*1
    if m2 == 2 :
        r2 = r2 + 20*2
    if m3 == 2 :
        r2 = r2 + 20*3
    if m4 == 2 :
        r2 = r2 + 20*4
    if m5 == 2 :
        r2 = r2 + 20*5
    if m6 == 2 :
        r2 = r2 + 20*6 #SPaire/DPaire

    if m1 == 3 or m2 == 3 or m3 == 3 or m4 == 3 or m5 == 3 or m6 == 3 :
        r2 = r2 + 150 #Brelan

    if m1 == 4 or m2 == 4 or m3 == 4 or m4 == 4 or m5 == 4 or m6 == 4 :
        r2 = r2 + 180 #Carré

    if m1 == 5 or m2 == 5 or m3 == 5 or m4 == 5 or m5 == 5 or m6 == 5 :
        r2 = r2 + 200
        
    resultat()
    

#Programme principal

'''a = float (input("Relancer dé1 ? 1 ou 0 "))

if a == 1 :
    main()'''
