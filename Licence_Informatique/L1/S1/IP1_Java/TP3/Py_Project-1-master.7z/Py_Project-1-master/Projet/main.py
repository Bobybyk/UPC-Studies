from tkinter import *
from tkinter import messagebox
from tkinter import simpledialog
from tkinter import filedialog
import PAD



player = 1 #Quel joueur doit jouer
morpion1 = 0 #Savoir si le jeu a commence
c1 = c2 = c3 = c4 = c5 = c6 = c7 = c8 = c9 = 0 #Case du tapis de jeu si 1 = occupé par j1 \ si 2 = occupé par j2
gagnant = "None"


def sav_Name():      #Fonction de sauvegarde du nom du joueur
    global nom
    nom=Enom.get()
    
    global nom2
    nom2=Enom2.get()
    
    fichier = open("data.txt", "a")
    fichier.write("Nom des Joueurs\n#")
    fichier.write(nom)
    fichier.write("\n#")
    fichier.write(nom2)
    fichier.close
    menu()
    cadre.destroy()

'''def sav_HighScore():    #Fonction de sauvegarde des meilleurs scores
    fichier = open("data.txt", "a")
    fichier.write("High Score")
    fichier.write("$")

    if txt[0] == '$':
        fichier.readline'''

def menu():  #Fonction créant un menu de sélection des jeux


    global cadre2
    cadre2=Tk()
    cadre2.title("Mini-Jeux")

    label1=Label(cadre2,text="Choisie le jeu ",font="arial 20 bold")
    label1.pack(side =TOP)

    bouton2=Button(cadre2,text="Morpion",font="arial 20 bold", command=morpion)
    bouton2.pack(side =LEFT)

    bouton3=Button(cadre2,text="Poker aux dés",font="arial 20 bold", command=PAD_Launch)
    bouton3.pack(side =RIGHT)


def PAD_Launch():
    
    PAD.main()

def morpion():

    global morpion1

    if(morpion1 == 0):
        global cadre2
        cadre2.destroy()

    

    global cadre3

    morpion1 = 1
    
    cadre3=Tk()
    cadre3.title("Morpion")
    
    info2=Label(cadre3,text="Le Morpion :",font="arial 20 bold")
    info2.grid()

    global joueur
    joueur=Label(cadre3,text="Tour de " + nom,font="arial 20 bold")
    joueur.grid()

    global jeu
    jeu=Frame(cadre3, width =1440, height =1440, bg="grey")
    jeu.grid()

    global can1
    can1 = Canvas(jeu, width =160, height =160, bg ='white')
        
    global can2
    can2 = Canvas(jeu, width =160, height =160, bg ='white')

    global can3
    can3 = Canvas(jeu, width =160, height =160, bg ='white')

    global can4
    can4 = Canvas(jeu, width =160, height =160, bg ='white')

    global can5
    can5 = Canvas(jeu, width =160, height =160, bg ='white')

    global can6
    can6 = Canvas(jeu, width =160, height =160, bg ='white')

    global can7
    can7 = Canvas(jeu, width =160, height =160, bg ='white')

    global can8
    can8 = Canvas(jeu, width =160, height =160, bg ='white')

    global can9
    can9 = Canvas(jeu, width =160, height =160, bg ='white')
    
        
        

        
    can1.grid(row =2, column =0, rowspan =3, padx =10, pady =10)
        
    can2.grid(row =2, column =1, rowspan =3, padx =10, pady =10)

    can3.grid(row =1, column =2, rowspan =3, padx =10, pady =10)

    can4.grid(row =7, column =0, rowspan =3, padx =10, pady =10)

    can5.grid(row =7, column =1, rowspan =3, padx =10, pady =10)

    can6.grid(row =7, column =2, rowspan =3, padx =10, pady =10)

    can7.grid(row =14, column =0, rowspan =3, padx =10, pady =10)

    can8.grid(row =14, column =1, rowspan =3, padx =10, pady =10)

    can9.grid(row =14, column =2, rowspan =3, padx =10, pady =10)




    #Detection des clics dans les cases#

    can1.bind("<Button-1>", place1)
    can2.bind("<Button-1>", place2)
    can3.bind("<Button-1>", place3)
    can4.bind("<Button-1>", place4)
    can5.bind("<Button-1>", place5)
    can6.bind("<Button-1>", place6)
    can7.bind("<Button-1>", place7)
    can8.bind("<Button-1>", place8)
    can9.bind("<Button-1>", place9)


    ####################################


    cadre3.mainloop()




###################################################################################################################





def place1(event): #Si la case cliqué est c1

    global player 
    global cadre3 # Ces variables permettent une interaction avec le reste du jeu
    global c1
    global joueur
    

    #print("clic1")

    #print(c1)
    
    if(c1 == 0): #Test si la case est occupé

        #print("clic1.5")

        if(player == 1): #Si c'est le joueur 1

            photo1 = PhotoImage(file ='cross.gif')  #Assigne une image a une variable
            item1 = can1.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can1.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image

            c1 = 1  #Case appartient au joueur 1
            player = 2  #Joueur qui va joue

            joueur.config(text="Tour de " + nom2)
            
            #print("clic2")

        else: # Sinon c'est le joueur 2
            
            photo1 = PhotoImage(file ='circle.gif')     #Assigne une image a une variable
            item1 = can1.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can1.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image

            c1 = 2  #Case appartient au joueur 2
            player = 1  #Joueur qui va joue

            joueur.config(text="Tour de " + nom)
        
            #print("clic3")

        resultat()  #Appel ce cette fonction pour verifier si il y a victoire

    cadre3.mainloop()
        

def place2(event): #Si la case cliqué est c1

    global player 
    global cadre3 # Ces variables permettent une interaction avec le reste du jeu
    global c2
    
    
    
    if(c2 == 0): #Test si la case est occupé

        if(player == 1): #Si c'est le joueur 1

            photo1 = PhotoImage(file ='cross.gif')  #Assigne une image a une variable
            item1 = can2.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can2.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image


            c2 = 1  #Case appartient au joueur 1
            player = 2  #Joueur qui va joue
            
            joueur.config(text="Tour de " + nom2)

        else: # Sinon c'est le joueur 2
            
            photo1 = PhotoImage(file ='circle.gif')     #Assigne une image a une variable
            item1 = can2.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can2.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image

            c2 = 2  #Case appartient au joueur 2
            player = 1  #Joueur qui va joue
        
            joueur.config(text="Tour de " + nom)

        resultat()  #Appel ce cette fonction pour verifier si il y a victoire

    cadre3.mainloop()


def place3(event): #Si la case cliqué est c1

    global player 
    global cadre3 # Ces variables permettent une interaction avec le reste du jeu
    global c3

    
    
    if(c3 == 0): #Test si la case est occupé

        if(player == 1): #Si c'est le joueur 1

            photo1 = PhotoImage(file ='cross.gif')  #Assigne une image a une variable
            item1 = can3.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can3.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image


            c3 = 1  #Case appartient au joueur 1
            player = 2  #Joueur qui va joue
            
            joueur.config(text="Tour de " + nom2)

        else: # Sinon c'est le joueur 2
            
            photo1 = PhotoImage(file ='circle.gif')     #Assigne une image a une variable
            item1 = can3.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can3.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image

            c3 = 2  #Case appartient au joueur 2
            player = 1  #Joueur qui va joue
        
            joueur.config(text="Tour de " + nom)

        resultat()  #Appel ce cette fonction pour verifier si il y a victoire

    cadre3.mainloop()
    

def place4(event): #Si la case cliqué est c1

    global player 
    global cadre3 # Ces variables permettent une interaction avec le reste du jeu
    global c4

    
    
    if(c4 == 0): #Test si la case est occupé

        if(player == 1): #Si c'est le joueur 1

            photo1 = PhotoImage(file ='cross.gif')  #Assigne une image a une variable
            item1 = can4.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can4.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image


            c4 = 1  #Case appartient au joueur 1
            player = 2  #Joueur qui va joue
            
            joueur.config(text="Tour de " + nom2)

        else: # Sinon c'est le joueur 2
            
            photo1 = PhotoImage(file ='circle.gif')     #Assigne une image a une variable
            item1 = can4.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can4.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image

            c4 = 2  #Case appartient au joueur 2
            player = 1  #Joueur qui va joue
        
            joueur.config(text="Tour de " + nom)

        resultat()  #Appel ce cette fonction pour verifier si il y a victoire

    cadre3.mainloop()


def place5(event): #Si la case cliqué est c1

    global player 
    global cadre3 # Ces variables permettent une interaction avec le reste du jeu
    global c5

    
    
    if(c5 == 0): #Test si la case est occupé

        if(player == 1): #Si c'est le joueur 1

            photo1 = PhotoImage(file ='cross.gif')  #Assigne une image a une variable
            item1 = can5.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can5.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image


            c5 = 1  #Case appartient au joueur 1
            player = 2  #Joueur qui va joue
            
            joueur.config(text="Tour de " + nom2)

        else: # Sinon c'est le joueur 2
            
            photo1 = PhotoImage(file ='circle.gif')     #Assigne une image a une variable
            item1 = can5.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can5.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image

            c5 = 2  #Case appartient au joueur 2
            player = 1  #Joueur qui va joue
        
            joueur.config(text="Tour de " + nom)

        resultat()  #Appel ce cette fonction pour verifier si il y a victoire

    cadre3.mainloop()


def place6(event): #Si la case cliqué est c1

    global player 
    global cadre3 # Ces variables permettent une interaction avec le reste du jeu
    global c6

    
    
    if(c6 == 0): #Test si la case est occupé

        if(player == 1): #Si c'est le joueur 1

            photo1 = PhotoImage(file ='cross.gif')  #Assigne une image a une variable
            item1 = can6.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can6.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image


            c6 = 1  #Case appartient au joueur 1
            player = 2  #Joueur qui va joue
            
            joueur.config(text="Tour de " + nom2)

        else: # Sinon c'est le joueur 2
            
            photo1 = PhotoImage(file ='circle.gif')     #Assigne une image a une variable
            item1 = can6.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can6.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image

            c6 = 2  #Case appartient au joueur 2
            player = 1  #Joueur qui va joue
        
            joueur.config(text="Tour de " + nom)

        resultat()  #Appel ce cette fonction pour verifier si il y a victoire

    cadre3.mainloop()


def place7(event): #Si la case cliqué est c1

    global player 
    global cadre3 # Ces variables permettent une interaction avec le reste du jeu
    global c7

   
    
    if(c7 == 0): #Test si la case est occupé

        if(player == 1): #Si c'est le joueur 1

            photo1 = PhotoImage(file ='cross.gif')  #Assigne une image a une variable
            item1 = can7.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can7.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image


            c7 = 1  #Case appartient au joueur 1
            player = 2  #Joueur qui va joue
            
            joueur.config(text="Tour de " + nom2)

        else: # Sinon c'est le joueur 2
            
            photo1 = PhotoImage(file ='circle.gif')     #Assigne une image a une variable
            item1 = can7.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can7.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image

            c7 = 2  #Case appartient au joueur 2
            player = 1  #Joueur qui va joue
        
            joueur.config(text="Tour de " + nom)

        resultat()  #Appel ce cette fonction pour verifier si il y a victoire

    cadre3.mainloop()


def place8(event): #Si la case cliqué est c1

    global player 
    global cadre3 # Ces variables permettent une interaction avec le reste du jeu
    global c8

    
    
    if(c8 == 0): #Test si la case est occupé

        if(player == 1): #Si c'est le joueur 1

            photo1 = PhotoImage(file ='cross.gif')  #Assigne une image a une variable
            item1 = can8.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can8.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image


            c8 = 1  #Case appartient au joueur 1
            player = 2  #Joueur qui va joue
            
            joueur.config(text="Tour de " + nom2)

        else: # Sinon c'est le joueur 2
            
            photo1 = PhotoImage(file ='circle.gif')     #Assigne une image a une variable
            item1 = can8.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can8.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image

            c8 = 2  #Case appartient au joueur 2
            player = 1  #Joueur qui va joue
        
            joueur.config(text="Tour de " + nom)

        resultat()  #Appel ce cette fonction pour verifier si il y a victoire

    cadre3.mainloop()


def place9(event): #Si la case cliqué est c1

    global player 
    global cadre3 # Ces variables permettent une interaction avec le reste du jeu
    global c9

    
    
    if(c9 == 0): #Test si la case est occupé

        if(player == 1): #Si c'est le joueur 1

            photo1 = PhotoImage(file ='cross.gif')  #Assigne une image a une variable
            item1 = can9.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can9.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image


            c9 = 1  #Case appartient au joueur 1
            player = 2  #Joueur qui va joue
            
            joueur.config(text="Tour de " + nom2)

        else: # Sinon c'est le joueur 2
            
            photo1 = PhotoImage(file ='circle.gif')     #Assigne une image a une variable
            item1 = can9.create_image(80, 80, image = photo1)   #Cree un objet contenant l'image avec parametrage de la taille
            can9.itemconfig(item1)  #reconfiguation du canva pour lui appliquer l'item contenant l'image

            c9 = 2  #Case appartient au joueur 2
            player = 1  #Joueur qui va joue
        
            joueur.config(text="Tour de " + nom)

        resultat()  #Appel ce cette fonction pour verifier si il y a victoire

    cadre3.mainloop()



###################################################################################################################


def resultat(): #Condition de victoire
    #Le joueur est gagnant si il a declanché une des conditions suivantes.
    #Si la victoire est declanché alors c'est forcement le dernier joueur qui a joué qui a gagné


    if(c1 == c2 == c3 != 0 or c4 == c5 == c6 != 0 or c7 == c8 == c9 != 0): #LIGNES
        print("Victoire Ligne")

        if(player == 1):        #Si c'est le joueur 1 qui a jouer en dernier
            print(" Joueur 2")
            gagnant = "du joueur 2"
            
        else:       #Sinon c'est le joueur 2 qui a gagné
            print(" Joueur 1")
            gagnant = "du joueur 1"

        
        fin(gagnant)        #Appel de fin() ayant pour parametre une variable


    elif(c1 == c4 == c7 != 0 or c2 == c5 == c8 != 0 or c3 == c6 == c9 != 0): #COLONNES
        print("Victoire Colonne")

        if(player == 1):        #Si c'est le joueur 1 qui a jouer en dernier
            print(" Joueur 2")
            gagnant = " du joueur 2"
            
        else:       #Sinon c'est le joueur 2 qui a gagné
            print(" Joueur 1")
            gagnant = "du joueur 1"

        fin(gagnant)        #Appel de fin() ayant pour parametre une variable

        

    elif(c1 == c5 == c9 != 0 or c3 == c5 == c7 != 0): #DIAGONALES
        print("Victoire Diagonale")

        if(player == 1):        #Si c'est le joueur 1 qui a jouer en dernier
            print(" Joueur 2")
            gagnant = "du joueur 2"
            
        else:       #Sinon c'est le joueur 2 qui a gagné
            print(" Joueur 1")
            gagnant = "du joueur 1"

        fin(gagnant)        #Appel de fin() ayant pour parametre une variable

        

    elif(c1 != 0 and c2 != 0 and c3 != 0 and c4 != 0 and c5 != 0 and c6 != 0 and c7 != 0 and c8 != 0 and c9 != 0): #Egalite
        print("Egalité")
        gagnant = "de personne"
        
        fin(gagnant)        #Appel de fin() ayant pour parametre une variable
        
    
##################################################################################################################


def fin(gagnant):

    global player
    global c1
    global c2
    global c3
    global c4               #Import des variables necessaires
    global c5
    global c6
    global c7
    global c8
    global c9

    cadre3.destroy()

    c1 = c2 = c3 = c4 = c5 = c6 = c7 = c8 = c9 = 0 #Reinitialisation des valeurs
    player = 1
    

    #print(c1)
    #print(c9)
    #print(morpion1)
    #print(player)



    global cadre4
    cadre4=Tk()      #Creation d'une fenetre
    cadre4.title("Arrêter ou Rejouer?")   #Nom de la fenetre

    info=Label(cadre4,text="Victoire " + gagnant ,font="arial 20 bold")     #Emplacement de texte
    info.pack(side=TOP)
    
    continuer=Button(cadre4,text="Rejouer",font="arial 20 bold", command=rejouer)     #Emplacement de texte
    continuer.pack(side=LEFT)

    stop=Button(cadre4,text="Arrêter",font="arial 20 bold", command=arreter)     #Emplacement de texte
    stop.pack(side=RIGHT)

    kill=Button(cadre4,text="Quitter",font="arial 20 bold", command=quitter)     #Emplacement de texte
    kill.pack(side=RIGHT)
    

    gagnant = "None"    #Reinitialisation des valeurs


def rejouer(): 
    
    cadre4.destroy()    #Destruction de la fenetre "Arrêter ou Rejouer?"
    morpion()   #Appel de la fonction morpion

def arreter():

    global morpion1
    
    cadre4.destroy()    #Destruction de la fenetre "Arrêter ou Rejouer?"
    morpion1 = 0
    menu()  #Appel de la fonction menu

def quitter(): 
    
    quit() #Quitte le programme
    

##################################################################################################################




                        ################ Principale ################


cadre=Tk()      #Creation d'une fenetre
cadre.title("Mini-Jeux")   #Nom de la fenetre

info=Label(cadre,text="Bienvenue !!!",font="arial 20 bold")     #Emplacement de texte
info.grid(row=0,column=0)

text1=Label(cadre,text="Nom du Joueur 1 : ",font="arial 20 bold")       #Emplacement de texte
text1.grid(row=2,column=0)

text2=Label(cadre,text="Nom du Joueur 2 : ",font="arial 20 bold")       #Emplacement de texte
text2.grid(row=4,column=0)

Enom=Entry(cadre, width=20,font="arial 20 bold")    #Emplacement de saisie de texte
Enom.grid(row=3,column=0)

Enom2=Entry(cadre, width=20,font="arial 20 bold")    #Emplacement de saisie de texte
Enom2.grid(row=5,column=0)

confirm=Button(cadre,text="OK",font="arial 20 bold",command=sav_Name)    #Bouton de confirmation executant la fonction "sav"
confirm.grid(row=6,column=0,sticky=W+E)








