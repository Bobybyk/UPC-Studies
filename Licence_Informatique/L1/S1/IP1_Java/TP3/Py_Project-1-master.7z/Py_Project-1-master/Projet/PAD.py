import sys
from tkinter import *
from random import randrange

a=p=c=d=j1=j2=r1=r2=n1=n2=n3=n4=n5=n6=m1=m2=m3=m4=m5=m6=a1=b1=c1=d1=e1=a2=b2=c2=d2=e2=pr1=f2=pr2=z=f=dé1C=dé2C=dé3C=dé4C=dé5C=ContB=dé1C2=dé2C2=dé3C2=dé4C2=dé5C2=ContB2=0
ran = 5


def main() :

    global fenMain
    global f
    global f2
    global Cont 
    global ContB
    global Cont2
    global ContB2
    global dé1C
    global dé2C
    global dé3C
    global dé4C
    global dé5C
    global dé1C2
    global dé2C2
    global dé3C2
    global dé4C2
    global dé5C2

    f = 0
    f2 = 0
    Cont = 0
    ContB = 0
    Cont2 = 0
    ContB2 = 0
    dé1C = 0
    dé2C = 0
    dé3C = 0
    dé4C = 0
    dé5C = 0
    dé1C2 = 0
    dé2C2 = 0
    dé3C2 = 0
    dé4C2 = 0
    dé5C2 = 0
    
    fenMain = Tk()
    dJtext = Label(fenMain, text="Joueur 1 commence !", fg='red')
    dJtext.pack()
    dJ1 = Button(fenMain, text="Lancer les dés", command = joueur1)
    dJ1.pack()
    fenMain.mainloop()
    

def compteur() :

    global p
    global c
    global d
    global r1
    global r2
    global pr1
    global pr2
    global fenJ1
    global fenMa
    
    fenJ1.destroy()

    p = p + 1

    fenMa = Tk()
    
    MaMtext = Label(fenMa, text="Fin de la manche n°")
    MaMtext.grid(row = 1 , column = 0)
    
    MaMntext = Label(fenMa, text=p)
    MaMntext.grid(row = 1 , column = 1)

    if r1 < r2 :
        Ma1text = Label(fenMa, text="Manche remportée par joueur 2")
        Ma1text.grid(row = 3 , column = 0) 

    if r2 < r1 :
        Ma2text = Label(fenMa, text="Manche remportée par joueur 1")
        Ma2text.grid(row = 3 , column = 0)

    if r2 == r1 :
        Ma3text = Label(fenMa, text="Egalité")
        Ma3text.grid(row = 3 , column = 0)

    if p < 3 and r2 != r1 :
        MaS = Button(fenMa, text="Manche suivante", command = destroyM)
        MaS.grid(row = 4 , column = 0)
    elif p >= 3 and r2 < r1 :
        MaP1text = Label(fenMa, text="Partie remportée par joueur 1")
        MaP1text.grid(row = 4 , column = 0)
        MaP = Button(fenMa, text="Terminer", command = destroyP)
        MaP.grid(row = 5 , column = 0)
    elif p >= 3 and r1 < r2 :
        MaP2text = Label(fenMa, text="Partie remportée par joueur 2")
        MaP2text.grid(row = 4 , column = 0)
        MaP = Button(fenMa, text="Terminer", command = destroyP)
        MaP.grid(row = 5 , column = 0)        
    
    fenMa.mainloop()        
    
    
def joueur1() :

    fenMain.destroy()

    global c
    global d
    global a1
    global b1
    global c1
    global d1
    global e1
    
    a1 = randrange(1,7)
    b1 = randrange(1,7)
    c1 = randrange(1,7)
    d1 = randrange(1,7)
    e1 = randrange(1,7)

    Joueur1F()

def Joueur1F() :

    global a1
    global b1
    global c1
    global d1
    global e1
    global f
    global a
    global Cont
    global ContB
    
    if f == 0 :

        global fenJ1
        global can1
        global can2
        global can3
        global can4
        global can5
        global dé1C
        global dé2C
        global dé3C
        global dé4C
        global dé5C
        global ContB

        fenJ1 = Tk()
        f = f + 1
    
        J1text = Label(fenJ1, text="Joueur 1", fg='blue', font = "arial 18")
        J1text.grid(column = 2)
        can1 = Canvas(fenJ1, width = 160 , height = 160 , bg = 'white')
        can1.grid(row = 2 , column = 0 , rowspan = 3 , padx = 10 , pady = 10)
        can2 = Canvas(fenJ1, width = 160 , height = 160 , bg = 'white')
        can2.grid(row = 2 , column = 1 , rowspan = 3 , padx = 10 , pady = 10)
        can3 = Canvas(fenJ1, width = 160 , height = 160 , bg = 'white')
        can3.grid(row = 2 , column = 2 , rowspan = 3 , padx = 10 , pady = 10)
        can4 = Canvas(fenJ1, width = 160 , height = 160 , bg = 'white')
        can4.grid(row = 2 , column = 3 , rowspan = 3 , padx = 10 , pady = 10)
        can5 = Canvas(fenJ1, width = 160 , height = 160 , bg = 'white')
        can5.grid(row = 2 , column = 4 , rowspan = 3 , padx = 10 , pady = 10)

        if dé1C == 0 :
            global D1rY 
            D1rY = Button(fenJ1, text="Relancer dé1", command = dé1)
            D1rY.grid(column = 0)

        if dé2C == 0 :
            global D2rY
            D2rY = Button(fenJ1, text="Relancer dé2", command = dé2)
            D2rY.grid(row = 5 , column = 1)

        if dé3C == 0 :
            global D3rY
            D3rY = Button(fenJ1, text="Relancer dé3", command = dé3)
            D3rY.grid(row = 5 , column = 2)

        if dé4C == 0 :
            global D4rY
            D4rY = Button(fenJ1, text="Relancer dé4", command = dé4)
            D4rY.grid(row = 5 , column = 3)

        if dé5C == 0 :
            global D5rY
            D5rY = Button(fenJ1, text="Relancer dé5", command = dé5)
            D5rY.grid(row = 5 , column = 4)

        if ContB == 0 :
            global Cont
            Cont = Button(fenJ1, text="Continuer", command = cont)
            Cont.grid(row = 5 , column = 5)
            
        

    imgJ1Dé1 = PhotoImage(file ='D1.gif')
    imgJ1Dé2 = PhotoImage(file ='D2.gif')
    imgJ1Dé3 = PhotoImage(file ='D3.gif')
    imgJ1Dé4 = PhotoImage(file ='D4.gif')
    imgJ1Dé5 = PhotoImage(file ='D5.gif')
    imgJ1Dé6 = PhotoImage(file ='D6.gif')

    desJ1 = [imgJ1Dé1, imgJ1Dé2, imgJ1Dé3, imgJ1Dé4, imgJ1Dé5, imgJ1Dé6]    

    item1 = can1.create_image(80, 80, image = desJ1[a1 - 1])
    can1.itemconfig(item1)

    item2 = can2.create_image(80, 80, image = desJ1[b1 - 1])
    can2.itemconfig(item2)

    item3 = can3.create_image(80, 80, image = desJ1[c1 - 1])
    can3.itemconfig(item3)

    item4 = can4.create_image(80, 80, image = desJ1[d1 - 1])
    can4.itemconfig(item4)

    item5 = can5.create_image(80, 80, image = desJ1[e1 - 1])
    can5.itemconfig(item5)

    if dé1C and dé2C and dé3C and dé4C and dé5C == 1 :
        Cont.destroy()
        j1Resultat()
    
    fenJ1.mainloop()

def cont() :

    global Cont
    global ContB
    Cont.destroy()
    ContB = ContB + 1 
    D1rY.destroy()
    D2rY.destroy()
    D3rY.destroy()
    D4rY.destroy()
    D5rY.destroy()
    j1Resultat()
    

def dé1() :

    global a1
    global dé1C
    global D1rY
    a1 = randrange(1,7)
    dé1C = dé1C + 1
    D1rY.destroy()
    Joueur1F()

def dé2() :

    global b1
    global dé2C
    global D2rY
    b1 = randrange(1,7)
    dé2C  = dé2C + 1    
    D2rY.destroy()    
    Joueur1F()

def dé3() :

    global c1
    global dé3C
    global D3rY
    c1 = randrange(1,7)
    dé3C = dé3C + 1
    D3rY.destroy()
    Joueur1F()

def dé4() :

    global d1
    global dé4C
    global D4rY
    d1 = randrange(1,7)
    dé4C = dé4C + 1
    D4rY.destroy()
    Joueur1F()

def dé5() :

    global e1
    global dé5C
    global D5rY
    e1 = randrange(1,7)
    dé5C = dé5C + 1
    D5rY.destroy()
    Joueur1F()
                

def joueur2() : 

    global c
    global d
    global a2
    global b2
    global c2
    global d2
    global e2
    global ContJ2
    
    ContJ2.destroy()
    
    a2 = randrange(1,7)
    b2 = randrange(1,7)
    c2 = randrange(1,7)
    d2 = randrange(1,7)
    e2 = randrange(1,7)

    Joueur2F()


def Joueur2F() :

    global a2
    global b2
    global c2
    global d2
    global e2
    global f2
    global a2
    global Cont2
    
    if f2 == 0 :

        global fenJ1
        global can21
        global can22
        global can23
        global can24
        global can25
        global dé1C2
        global dé2C2
        global dé3C2
        global dé4C2
        global dé5C2
        global ContB2

        f2 = f2 + 1
    
        J2text = Label(fenJ1, text="Joueur 2", fg='red', font = "arial 18")
        J2text.grid(row = 7 , column = 2)
        can21 = Canvas(fenJ1, width = 160 , height = 160 , bg = 'white')
        can21.grid(row = 9 , column = 0 , rowspan = 3 , padx = 10 , pady = 10)
        can22 = Canvas(fenJ1, width = 160 , height = 160 , bg = 'white')
        can22.grid(row = 9 , column = 1 , rowspan = 3 , padx = 10 , pady = 10)
        can23 = Canvas(fenJ1, width = 160 , height = 160 , bg = 'white')
        can23.grid(row = 9 , column = 2 , rowspan = 3 , padx = 10 , pady = 10)
        can24 = Canvas(fenJ1, width = 160 , height = 160 , bg = 'white')
        can24.grid(row = 9 , column = 3 , rowspan = 3 , padx = 10 , pady = 10)
        can25 = Canvas(fenJ1, width = 160 , height = 160 , bg = 'white')
        can25.grid(row = 9 , column = 4 , rowspan = 3 , padx = 10 , pady = 10)

        if dé1C2 == 0 :
            global D1rY2
            D1rY2 = Button(fenJ1, text="Relancer dé1", command = dé21)
            D1rY2.grid(row = 12 , column = 0)

        if dé2C2 == 0 :
            global D2rY2
            D2rY2 = Button(fenJ1, text="Relancer dé2", command = dé22)
            D2rY2.grid(row = 12 , column = 1)

        if dé3C2 == 0 :
            global D3rY2
            D3rY2 = Button(fenJ1, text="Relancer dé3", command = dé23)
            D3rY2.grid(row = 12 , column = 2)

        if dé4C2 == 0 :
            global D4rY2
            D4rY2 = Button(fenJ1, text="Relancer dé4", command = dé24)
            D4rY2.grid(row = 12 , column = 3)

        if dé5C2 == 0 :
            global D5rY2
            D5rY2 = Button(fenJ1, text="Relancer dé5", command = dé25)
            D5rY2.grid(row = 12 , column = 4)

        if ContB2 == 0 :
            global Cont2
            Cont2 = Button(fenJ1, text="Continuer", command = cont2)
            Cont2.grid(row = 12 , column = 5)
            
        

    imgJ2Dé1 = PhotoImage(file ='D1R.gif')
    imgJ2Dé2 = PhotoImage(file ='D2R.gif')
    imgJ2Dé3 = PhotoImage(file ='D3R.gif')
    imgJ2Dé4 = PhotoImage(file ='D4R.gif')
    imgJ2Dé5 = PhotoImage(file ='D5R.gif')
    imgJ2Dé6 = PhotoImage(file ='D6R.gif')

    desJ2 = [imgJ2Dé1, imgJ2Dé2, imgJ2Dé3, imgJ2Dé4, imgJ2Dé5, imgJ2Dé6]    

    item21 = can21.create_image(80, 80, image = desJ2[a2 - 1])
    can21.itemconfig(item21)

    item22 = can22.create_image(80, 80, image = desJ2[b2 - 1])
    can22.itemconfig(item22)

    item23 = can23.create_image(80, 80, image = desJ2[c2 - 1])
    can23.itemconfig(item23)

    item24 = can24.create_image(80, 80, image = desJ2[d2 - 1])
    can24.itemconfig(item24)

    item25 = can25.create_image(80, 80, image = desJ2[e2 - 1])
    can25.itemconfig(item25)

    if dé1C2 and dé2C2 and dé3C2 and dé4C2 and dé5C2 == 1 :
        Cont2.destroy()
        j2Resultat()
    
    fenJ1.mainloop()    

def cont2() :

    global Cont2
    global ContB2
    Cont2.destroy()
    ContB2 = ContB2 + 1 
    D1rY2.destroy()
    D2rY2.destroy()
    D3rY2.destroy()
    D4rY2.destroy()
    D5rY2.destroy()
    j2Resultat()
    

def dé21() :

    global a2
    global dé1C2
    global D1rY2
    a2 = randrange(1,7)
    dé1C2 = dé1C2 + 1
    D1rY2.destroy()
    Joueur2F()

def dé22() :

    global b2
    global dé2C2
    global D2rY2
    b2 = randrange(1,7)
    dé2C2  = dé2C2 + 1    
    D2rY2.destroy()    
    Joueur2F()

def dé23() :

    global c2
    global dé3C2
    global D3rY2
    c2 = randrange(1,7)
    dé3C2 = dé3C2 + 1
    D3rY2.destroy()
    Joueur2F()

def dé24() :

    global d2
    global dé4C2
    global D4rY2
    d2 = randrange(1,7)
    dé4C2 = dé4C2 + 1
    D4rY2.destroy()
    Joueur2F()

def dé25() :

    global e2
    global dé5C2
    global D5rY2
    e2 = randrange(1,7)
    dé5C2 = dé5C2 + 1
    D5rY2.destroy()
    Joueur2F()
                



def j1Resultat() :

    global r1
    global n1
    global n2
    global n3
    global n4
    global n5
    global n6
    global j1
    global a
    global ContJ2
    
    j1 = [a1 , b1 , c1 , d1 , e1]

    n1 = j1.count(1)
    n2 = j1.count(2)
    n3 = j1.count(3)
    n4 = j1.count(4)
    n5 = j1.count(5)
    n6 = j1.count(6)

    if m1 == 1 :
        r1 = r1 + 1

    if m2 == 1 :
        r1 = r1 + 1

    if m3 == 1 :
        r1 = r1 + 1

    if m4 == 1 :
        r1 = r1 + 1

    if m5 == 1 :
        r1 = r1 + 1

    if m6 == 1 :
        r1 = r1 + 1
    
    if n1 == 1 and n2 == 1 and n3 == 1 and n4 == 1 and n5 == 1 : #Petite suite
        r1 = r1 + 160

    if n2 == 1 and n3 == 1 and  n4 == 1 and n5 == 1 and n6 == 1 : #Grande suite
        r1 = r1 + 170

    if n1 == 2 :
        r1 = r1 + 20*1
    if n2 == 2 :
        r1 = r1 + 20*2
    if n3 == 2 :
        r1 = r1 + 20*3
    if n4 == 2 :
        r1 = r1 + 20*4
    if n5 == 2 :
        r1 = r1 + 20*5
    if n6 == 2 :
        r1 = r1 + 20*6 #SPaire/DPaire

    if n1 == 3 or n2 == 3 or n3 == 3 or n4 == 3 or n5 == 3 or n6 == 3 :
        r1 = r1 + 150 #Brelan

    if n1 == 4 or n2 == 4 or n3 == 4 or n4 == 4 or n5 == 4 or n6 == 4 :
        r1 = r1 + 180 #Carré

    if n1 == 5 or n2 == 5 or n3 == 5 or n4 == 5 or n5 == 5 or n6 == 5 :
        r1 = r1 + 200

    a = a + 1


    J1textScoreVal = Label(fenJ1, text="Score joueur 1 = " , fg='blue' , font = "arial 18")
    J1textScoreVal.grid(row = 3 , column = 7)
    J1textScore = Label(fenJ1, text=r1, font = "arial 18")
    J1textScore.grid(row = 3 , column = 8)
    ContJ2 = Button(fenJ1, text="Continuer", command = joueur2)
    ContJ2.grid(row = 4 , column = 7)
    

    
    #fenJ1.mainloop()


def j2Resultat() :

    global r2
    global m1
    global m2
    global m3
    global m4
    global m5
    global m6
    global j2

    j2 = [a2 , b2 , c2 , d2 , e2]

    m1 = j2.count(1)
    m2 = j2.count(2)
    m3 = j2.count(3)
    m4 = j2.count(4)
    m5 = j2.count(5)
    m6 = j2.count(6)
    
    if m1 == 1 :
        r2 = r2 + 1

    if m2 == 1 :
        r2 = r2 + 1

    if m3 == 1 :
        r2 = r2 + 1

    if m4 == 1 :
        r2 = r2 + 1

    if m5 == 1 :
        r2 = r2 + 1

    if m6 == 1 :
        r2 = r2 + 1
                         
    
    if m1 == 1 and m2 == 1 and m3 == 1 and m4 == 1 and m5 == 1 : #Petite suite
        r2 = r2 + 160

    if m2 == 1 and m3 == 1 and  m4 == 1 and m5 == 1 and m6 == 1 : #Grande suite
        r2 = r2 + 170

    if m1 == 2 :
        r2 = r2 + 20*1
    if m2 == 2 :
        r2 = r2 + 20*2
    if m3 == 2 :
        r2 = r2 + 20*3
    if m4 == 2 :
        r2 = r2 + 20*4
    if m5 == 2 :
        r2 = r2 + 20*5
    if m6 == 2 :
        r2 = r2 + 20*6 #SPaire/DPaire

    if m1 == 3 or m2 == 3 or m3 == 3 or m4 == 3 or m5 == 3 or m6 == 3 :
        r2 = r2 + 150 #Brelan

    if m1 == 4 or m2 == 4 or m3 == 4 or m4 == 4 or m5 == 4 or m6 == 4 :
        r2 = r2 + 180 #Carré

    if m1 == 5 or m2 == 5 or m3 == 5 or m4 == 5 or m5 == 5 or m6 == 5 :
        r2 = r2 + 200
        
    J2textScoreVal = Label(fenJ1, text="Score joueur 2 = " , fg='red' , font = "arial 18")
    J2textScoreVal.grid(row = 11 , column = 7)
    J2textScore = Label(fenJ1, text=r2, font = "arial 18")
    J2textScore.grid(row = 11 , column = 8)
    ContJ2 = Button(fenJ1, text="Continuer", command = compteur)
    ContJ2.grid(row = 12 , column = 7)


def destroyM() :

    global fenMa
    fenMa.destroy()
    main()

def destroyP() :

    global fenMa
    fenMa.destroy()

    a=p=c=d=j1=j2=r1=r2=n1=n2=n3=n4=n5=n6=m1=m2=m3=m4=m5=m6=a1=b1=c1=d1=e1=a2=b2=c2=d2=e2=pr1=f2=pr2=z=f=dé1C=dé2C=dé3C=dé4C=dé5C=ContB=dé1C2=dé2C2=dé3C2=dé4C2=dé5C2=ContB2=0
    ran = 5
  

#Programme principal
#main()
