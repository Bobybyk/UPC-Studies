public class Expression {

    public static void main(String[] args) {

        /* Écrivez votre programme ici */

    }
}
