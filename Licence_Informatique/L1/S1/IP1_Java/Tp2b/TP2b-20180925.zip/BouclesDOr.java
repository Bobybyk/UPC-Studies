public class BouclesDOr {

    /* Écrivez vos fonctions ici */

    public static void main(String[] args) {

        /* Écrivez vos tests et le code à exécuter ici */

    }
}
