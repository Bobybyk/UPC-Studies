public class ExpressionVar {

    public static void main(String[] args) {

        /* Écrivez votre programme ici */

    }
}
