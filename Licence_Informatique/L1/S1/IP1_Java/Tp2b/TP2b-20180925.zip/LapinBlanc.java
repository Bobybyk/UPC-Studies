public class LapinBlanc {

    /* Écrivez votre fonction ici */

    public static void main(String[] args) {

        /* Écrivez vos tests */

    }
}
