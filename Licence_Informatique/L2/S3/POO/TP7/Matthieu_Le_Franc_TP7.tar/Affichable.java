public interface Affichable {
	
	public void afficher();

}