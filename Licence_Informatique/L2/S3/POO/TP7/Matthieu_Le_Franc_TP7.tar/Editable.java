import java.util.Scanner;

public interface Editable {
	public void editer(Scanner sc, boolean echo);
}