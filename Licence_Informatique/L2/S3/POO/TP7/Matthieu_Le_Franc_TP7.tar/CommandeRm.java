public class CommandeRm extends CommandeShell {
	
	public CommandeRm (Dossier racine, Dossier courant, String[] parametres) {
		super(racine, courant, parametres);
	}

	@Override
	public Dossier executer() {
		return null;
	}	
} 