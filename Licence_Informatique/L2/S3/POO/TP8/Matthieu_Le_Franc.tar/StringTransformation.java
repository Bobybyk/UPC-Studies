public interface StringTransformation {
	abstract String transf(String s);
}