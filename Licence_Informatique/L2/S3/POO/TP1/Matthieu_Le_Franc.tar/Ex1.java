public class Ex1 {


	/*	
	1/. Le type d'entrée de la méthode main est un tableau de chaines de charactères (String[]) et son type de sortie est void.
	3/. La fonction length()
	4/. hypot appartient à la classe Math 
	*/


	public static void main (String[] args) {
		System.out.println(args.length);
		double d = Math.hypot(8, 5);
	}

}
