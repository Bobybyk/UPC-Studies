public class BandeDessinee extends Livre {

	public BandeDessinee (String a, int n, String t) {
		super(a, n, t);
	}

}