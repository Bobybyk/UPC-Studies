public class Lanceur {

	public static void main (String[] args) {
		System.out.println("##### Démineur #####");
		Plateau p = new Plateau(5, 5, 5);
	}
}