import javax.swing.*;
import java.awt.*;

public class Modele {
	Color color;
    
    public Modele (int r, int g, int b) {
		this.color = new Color(r, g, b);
	}
}
