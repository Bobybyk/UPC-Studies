public class BoiteEspace extends Boite {

	public String toString() {
		return " ";
	}

	public int length() {
		return 1;
	}
}