public class Boite {
	
	public int length() {
		return 0;
	}

	public String toString() {
		return "";
	}
}