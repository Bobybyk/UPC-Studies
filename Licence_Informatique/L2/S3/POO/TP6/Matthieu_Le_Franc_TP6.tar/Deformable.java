public interface Deformable {

	Figure deformation (double coeffH, double coeffV);


}