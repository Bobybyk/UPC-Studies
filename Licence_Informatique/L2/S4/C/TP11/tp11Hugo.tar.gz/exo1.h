#ifndef EXO_1_H
#define EXO_1_H

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef struct{
	int x,y;
} paire;

void print_paire(paire*);

#endif