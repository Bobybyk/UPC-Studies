#include "file.h"

static void* decale(void* f, size_t d) {
	return (char*)f + d;
}

static void *put_fifo_no_shift(fifo f, void *pelem) {
	if(f->libre < f->last) {
		int *dest = memmove(f->libre,pelem,f->te);
		f->libre = decale(f->libre,1);
		return dest;
	}
	else
		return NULL;
}

fifo create_fifo(size_t capacite_init, size_t taille_elem) {
	fifo f = malloc(sizeof(struct file));
	assert(f != NULL);

	f->te = taille_elem;
	f->first = malloc(taille_elem * capacite_init);
	assert(f->first != NULL);

	f->libre = f->first;
	f->occupe = f->first;
	f->last = decale(f->first,taille_elem * capacite_init);
	return f;
}

void delete_fifo(fifo f) {
	free(f->first);
	free(f);
}

int empty_fifo(fifo f) {
	return (f->occupe == f->libre) ? 1 : 0;
}

void *get_fifo(fifo f, void *element) {
	if(empty_fifo(f))
		return NULL;
	memmove(element,f->first,f->te);
	return element;
}

void *put_fifo(fifo f, void *pelem) {
	if(f->libre != f->last) {
		put_fifo_no_shift(f,pelem);
	} else {
		if((f->libre - f->occupe) < (f->last - f->first)*0.25) {		//ALGO C
			f->first = realloc(f->first,(f->last) - (f->first) * (2) * (f->te));
			put_fifo_no_shift(f,pelem);
		} else {											//ALGO B
			void *p = f->occupe;
			memmove(f->first,f->occupe,(f->libre - f->occupe));
			f->occupe = f->first;
			f->libre = p;
			put_fifo_no_shift(f,pelem);
		}
	}
}

void print_fifo(fifo f) {

}