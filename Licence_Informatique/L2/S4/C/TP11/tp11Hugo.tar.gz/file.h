#ifndef FILE_H
#define FILE_H

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

typedef struct file{
void *first; /*pointeur debut de tableau*/
void *last; /*pointeur fin de tableau*/
size_t te; /*taille d’un element en octets*/
void *occupe; /*pointeur premier element de la file*/
void *libre; /*pointeur le premier element libre*/
} *fifo;

fifo create_fifo(size_t, size_t);
void delete_fifo(fifo);
void *get_fifo(fifo, void*);
void *put_fifo(fifo, void*);
void print_fifo(fifo);

#endif