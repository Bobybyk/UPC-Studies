#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "exo1.h"
#include "file.h"

int main(int argc, char const *argv[]) {
	
	// EXO 1
	/*
	int a = 15;
	void *pt = &a;

	printf("%d\n",a);
	*((int*)pt) = 42;
	printf("%d\n",a);

	*((int*)pt) *= *((int*)pt);	
	printf("%d\n",a);

	paire b;
	b.x=2;
	b.y=2;
	pt = &b;

	print_paire(pt);

	((paire*) pt)->y=12;
	print_paire(pt);*/

	//EXO 2
	fifo f = create_fifo(2,sizeof(int));
	delete_fifo(f);

	return 0;
}