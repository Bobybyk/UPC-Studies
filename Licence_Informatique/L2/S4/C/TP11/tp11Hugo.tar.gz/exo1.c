#include "exo1.h"

void print_paire(paire *p) {
	printf("x=%d\ny=%d\n",p->x,p->y);
}