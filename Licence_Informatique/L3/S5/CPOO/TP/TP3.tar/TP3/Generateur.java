interface Generateur {
	
}