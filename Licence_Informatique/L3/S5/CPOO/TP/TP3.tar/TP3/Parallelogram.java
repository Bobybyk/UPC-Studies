public class Parallelogram extends Quadrilateral {

	public Parallelogram() {
		
	}
}