public interface Set{
    boolean add( Integer x);
    boolean remove (Integer x);
    boolean contains( Integer x);
}