public class Window {
    public Node pred, curr;

    public Window(Node pred, Node curr) {
        this.pred = pred;
        this.curr = curr;
    }

}
