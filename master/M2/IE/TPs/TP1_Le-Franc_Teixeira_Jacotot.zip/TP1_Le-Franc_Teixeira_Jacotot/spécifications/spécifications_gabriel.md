Specs

Feu tricolore :
- 3 lampes de couleurs diffèrentes(rouge (haut),orange(milieu),vert(bas)) aligné verticalement
- Un système qui permet d'allumer les lumières et les éteindres
- une seule lampe doit être allumé à un moment T
- 3 transitions défini dans cet ordre là et le cycle est infini: 
    - Rouge -> Orange
    - Orange-> Vert
    - Vert  -> Rouge
- La lumière orange doit être courte mais assez longue pour permettre aux voitures de s'arrêter si elles le peuvent(dépend de la limite de vitesse de la route)
- La lumière verte et rouge doivent être allumés aussi longtemps l'une que l'autre. Le temps doit être limité et dépends de la limite de vitesse de la route mais pas trop long.