Spécification feu tricolore:

3 ampoules colorées:
- 1 rouge en haut
- 1 orange au milieu
- 1 vert en bas

Les 3 ampoules ne peuvent pas être allumées en même temps.
Le feu alterne entre les 3 couleurs dans cet ordre: rouge, vert, orange

Les feux restent dans l'état rouge et vert pendant la même durée, seule l'état orange est plus court que les deux autres.

Le feu vert signifie que la voiture peut passer.
Le feu orange indique que le feu va bientôt passer au rouge mais la voiture peut tojours avancer.
Le feu rouge indique que la voiture doit attendre que le feu soit vert pour avancer.