public class Stamped<T>{
    T reference;
    int stamp;
}