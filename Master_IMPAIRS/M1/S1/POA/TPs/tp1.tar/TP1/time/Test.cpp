#include "TimeStamp.hpp"

int main() {
	// minuit
	TimeStamp time{9, 899, 60};
	time.affiche();
	return 0;
}