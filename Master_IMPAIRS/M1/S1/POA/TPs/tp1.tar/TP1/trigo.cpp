#include <cmath>

void sinus(double, char) {

}

int main() {
	return 0;
}