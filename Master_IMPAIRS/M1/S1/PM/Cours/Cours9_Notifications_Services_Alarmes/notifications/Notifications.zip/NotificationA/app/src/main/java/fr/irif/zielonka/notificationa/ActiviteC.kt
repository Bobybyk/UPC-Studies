package fr.irif.zielonka.notificationa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ActiviteC : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_activite_c)
    }
}