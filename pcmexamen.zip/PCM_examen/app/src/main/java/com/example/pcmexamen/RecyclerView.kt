package com.example.pcmexamen

class RecyclerView(private var mails: MutableList<BDMails>) {

}