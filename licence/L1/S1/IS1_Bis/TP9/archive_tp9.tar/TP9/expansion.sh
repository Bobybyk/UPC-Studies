#! /usr/bin/env bash

echo "Le chemin absolu de mon répertoire courant est $HOME"
echo "Le résultat de la commande whoami est $(whoami)"
echo "Le produit de 33 par 17 vaut $((33*17))"
echo "Il a agi anticonstitutionnellement anticonventionnellement antisocialement."
MARY=supercalifragilisticexpialidocious
