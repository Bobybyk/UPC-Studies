TOTO=whoami

echo "J'aime bien utiliser la commande \"$TOTO\""
echo "Ma variable \$TOTO contient '$TOTO'."
echo "Mon login est "
echo "La commande d'aujourd'hui est \\whoami\\"
echo "whoareyou, c'est une commande imaginaire !"

