#! /usr/bin/env bash
echo "ceci est le r�sultat de l'ex�cution du fichier fic.sh."

