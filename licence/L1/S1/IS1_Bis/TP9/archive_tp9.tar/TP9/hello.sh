echo $NOM
