public class Et extends Predicat {

}