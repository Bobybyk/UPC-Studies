public class DictionnaireBilingue extends Dictionnaire {

	public DictionnaireBilingue (String l, int t, String titre) {
		super(l, t, titre);
	}

}