public class Predicat {

	public boolean estVrai (Media m) {
		if (m instanceof Media) {
			return true;
		} return false;
	}
}