public class Manga extends Livre{

	public Manga (String a, int n, String t) {
		super(a, n, t);
	}

}