public class Pion extends Piece {

	public Pion (boolean b) {

		super(b, "p");
	}
}