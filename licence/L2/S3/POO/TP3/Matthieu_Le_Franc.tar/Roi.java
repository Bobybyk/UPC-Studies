public class Roi extends Piece {
	
	public Roi (boolean b) {
		super(b, "r");
	}
}