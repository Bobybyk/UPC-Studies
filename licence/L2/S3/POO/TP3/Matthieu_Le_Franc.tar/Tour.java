public class Tour extends Piece {

	public Tour (boolean b) {
		super(b, "t");
	}
}