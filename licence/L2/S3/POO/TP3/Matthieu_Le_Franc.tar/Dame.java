public class Dame extends Piece {

	public Dame (boolean b) {
		super(b, "d");
	}
}