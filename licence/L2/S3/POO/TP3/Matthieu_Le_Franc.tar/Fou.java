public class Fou extends Piece {

	public Fou (boolean b) {
		super(b, "f");
	}
}