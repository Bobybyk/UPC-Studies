public class Cavalier extends Piece {

	public Cavalier (boolean b) {
		super(b, "c");
	}
}